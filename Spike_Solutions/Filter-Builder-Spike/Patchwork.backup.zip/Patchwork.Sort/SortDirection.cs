namespace Patchwork.Sort;

public enum SortDirection
{
  Ascending, Descending
}
