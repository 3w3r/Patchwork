﻿using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using DatabaseSchemaReader.DataSchema;
using Microsoft.VisualBasic;

namespace Patchwork.Schema;

public class SchemaDiscoveryBuilder
{
  private string _connectionString;
  public SchemaDiscoveryBuilder(string connectionString)
  {
    _connectionString = connectionString;
  }
  public DatabaseMetadata ReadSchema(DbConnection connection)
  {
    var dbReader = new DatabaseSchemaReader.DatabaseReader(connection);

    var dbS = dbReader.AllSchemas();
    var dbT = dbReader.AllTables();
    var dbV = dbReader.AllViews();

    var tables = dbT.Select(t => new Table(t.Name, t.Description,
                                           t.Columns.Select(c => new Column(c.Name, c.Description, c.DbDataType,
                                                                            c.IsPrimaryKey, c.IsForeignKey, c.ForeignKeyTableName,
                                                                            c.IsAutoNumber,
                                                                            c.IsComputed,
                                                                            c.IsUniqueKey,
                                                                            c.IsIndexed)).ToList().AsReadOnly())
    );

    var views = dbV.Select(v => new View(v.Name, v.Description,
                                         v.Columns.Select(c => new Column(c.Name, c.Description, c.DbDataType,
                                                                          c.IsPrimaryKey, c.IsForeignKey, c.ForeignKeyTableName,
                                                                          c.IsAutoNumber,
                                                                          c.IsComputed,
                                                                          c.IsUniqueKey,
                                                                          c.IsIndexed)).ToList().AsReadOnly())
    );

    var metadata = new DatabaseMetadata(dbS.Select(s =>
    {
      var tables = dbT.Where(t => t.SchemaOwner == s.Name)
                      .Select(t => new Table(t.Name, t.Description,
                                             t.Columns.Select(c => new Column(c.Name, c.Description, c.DbDataType,
                                                                              c.IsPrimaryKey, c.IsForeignKey, c.ForeignKeyTableName,
                                                                              c.IsAutoNumber,
                                                                              c.IsComputed,
                                                                              c.IsUniqueKey,
                                                                              c.IsIndexed)).ToList().AsReadOnly())
                             ).ToList().AsReadOnly();

      var views = dbV.Where(t => t.SchemaOwner == s.Name)
                     .Select(v => new View(v.Name, v.Description,
                                           v.Columns.Select(c => new Column(c.Name, c.Description, c.DbDataType,
                                                                            c.IsPrimaryKey, c.IsForeignKey, c.ForeignKeyTableName,
                                                                            c.IsAutoNumber,
                                                                            c.IsComputed,
                                                                            c.IsUniqueKey,
                                                                            c.IsIndexed)).ToList().AsReadOnly())
                           ).ToList().AsReadOnly();

      return new Schema(s.Name, tables, views);

    }).ToList().AsReadOnly());


    return metadata;
  }
}

public record DatabaseMetadata(ReadOnlyCollection<Schema> Schemas);

public record Schema(string Name,
                     ReadOnlyCollection<Table> Tables,
                     ReadOnlyCollection<View> Views);
public record Table(string Name, string Description, ReadOnlyCollection<Column> Columns);
public record View(string Name, string Description, ReadOnlyCollection<Column> Columns);
public record Column(string Name, string Description, string DbDataType,
                     bool IsPrimaryKey,
                     bool IsForeignKey, string ForeignKeyTableName,
                     bool IsAutoNumber,
                     bool IsComputed,
                     bool IsUniqueKey,
                     bool IsIndexed);
